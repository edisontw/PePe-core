# Standalone smoke build

The test is linked against the Windows x86_64 `libleveldb.a` produced by the verified PEPEPOW toolchain. Commits after `3f83d4b9f551afcdb48d13cee777d538475a5af1` change only docs and add the smoke source under `src`; `git diff 3f83d4b..e6c5b82 -- src` confirms the production LevelDB implementation used here matches the current branch.

```bash
x86_64-w64-mingw32-g++ -std=c++11 -O2 -static -static-libgcc -static-libstdc++ \
  -DLEVELDB_PLATFORM_WINDOWS -DWINVER=0x0500 -D__USE_MINGW_ANSI_STDIO=1 \
  -I"$SRC/src/leveldb/include" -I"$SRC/src/leveldb" \
  "$SRC/src/leveldb/db/win_block_index_mmap_smoke.cc" \
  "$BUILD/src/leveldb/libleveldb.a" \
  -lshlwapi -lws2_32 \
  -o win_block_index_mmap_smoke.exe
```

Run the resulting console executable on 64-bit Windows. Cross-compiling on Linux does not validate Windows file-delete behavior.
