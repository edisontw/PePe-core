# Windows mmap/compaction regression smoke test

This is a standalone synthetic LevelDB test. It does not use Qt, a PEPEPOW wallet, or a production chain database.

1. Create a new empty scratch parent, for example `C:\Temp\pepe-mmap-test-parent`.
2. Open Command Prompt in the directory containing `win_block_index_mmap_smoke.exe`.
3. Run:

```bat
win_block_index_mmap_smoke.exe C:\Temp\pepe-mmap-test-parent
```

The program creates two unique PID-namespaced subdirectories under that existing parent, first with the mmap gate off (`readfile` control), then with mmap enabled. Each case writes and updates 6,000 keys over three rounds, calls `CompactRange`, verifies sampled values, compares live SST counts with disk files, closes the DB, and destroys only its own temporary DB.

Pass requires these final lines and exit code 0:

```text
PASS readfile ...
PASS mmap ... mapped=<positive value>
PASS Windows block-index mmap compaction regression
```

If it fails, keep the console output and scratch directory for investigation. Do not point this test at a wallet or real datadir. On a prior failed run, inspect any existing `pepe-mmap-smoke-*` directory before manually removing it; the test refuses to reuse an existing PID path.
