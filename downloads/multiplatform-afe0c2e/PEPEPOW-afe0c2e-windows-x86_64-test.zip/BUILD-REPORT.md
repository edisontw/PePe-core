# PEPEPOW Windows x64 integration test — PR #4–#10

Temporary community test build; integration source afe0c2e70acf32de6aae44c5579383c7b273c539, baseline master 38e801428688dfd0aee272b4a91819ac1a13ab4e, latest PR #6 fdd69238bdece615044a3fce56e327e8b471dc07. This includes all previous PR #4–#10 integration changes. Two integration-only casts in new diagnostic log arguments avoid undefined static constant link errors; quorum logic is unchanged.

Ubuntu 24.04 MinGW GCC 13 win32, static Qt 5.5, Boost 1.63, OpenSSL 1.0.1u, BDB 4.8 and OpenLibm 0.8.7; GUI, wallet, QR enabled; UPnP/ZMQ disabled. Updated source was compiled and Qt/daemon linked; compatible unchanged CLI objects reused. All binaries stripped and verified PE32+ x86-64; imports Windows system DLLs only. SHA256SUMS.txt records hashes.

User reported an earlier Qt build tested OK, not this latest build. No Windows execution, live masternode quorum, production wallet or transaction validation was performed for this version. The original broad make's unrelated libdashconsensus target was not tested; only these application targets were built. Test using backups and test funds.
