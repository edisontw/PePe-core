# PEPEPOW Linux AArch64 integration test

Source commit afe0c2e70acf32de6aae44c5579383c7b273c539, includes PR #4–#10. Cross-built on Ubuntu 20.04 with GCC 9; wallet/Berkeley DB 4.8 and QR enabled; UPnP and ZMQ disabled. Daemon/CLI use repository depends libraries; Qt uses Ubuntu 20.04 ARM64 Qt 5.12, dynamically linked. SHA256SUMS.txt records file hashes.

Qt requires compatible ARM64 runtime packages: libqt5network5 libqt5widgets5 libqt5gui5 libqt5dbus5 libqt5core5a libqrencode4 libprotobuf17 and the Qt xcb platform dependencies on a graphical system. All executables require compatible ARM64 glibc and libstdc++; built using Ubuntu 20.04 ARM64 libraries. Other distributions and library versions have not been validated.

Validated using qemu-aarch64 with Ubuntu 20.04 ARM64 libraries: Qt offscreen -version; daemon and CLI version; isolated regtest daemon startup, getblockchaininfo, getwalletinfo, and graceful shutdown. No native ARM hardware, interactive GUI, production chain synchronization or real wallet transaction tests were performed. Use backed-up wallet data and test funds.

PR #6 HEAD fdd69238bdece615044a3fce56e327e8b471dc07 adds signed recovery quorum and stale ping checks. Two integration-only casts in diagnostic log arguments fix undefined static constant references; logic is unchanged. Live recovery, masternode counts and real transaction behavior are not validated by the isolated regtest smoke.
