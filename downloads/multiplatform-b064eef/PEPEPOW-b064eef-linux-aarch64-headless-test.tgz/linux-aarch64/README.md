# PEPEPOW Linux AArch64 headless integration test

Source commit b064eef45f4fbc47dbe338e5840cf17b6a4ed428, includes PR #4–#10. Ubuntu 20.04 cross compiler GCC 9 with repository depends libraries: wallet/Berkeley DB 4.8 enabled, UPnP and ZMQ disabled. This package contains daemon and CLI only; ARM64 Qt was not built. AArch64 ELF dynamically links system glibc and libstdc++; built against Ubuntu 20.04 sysroot. Other systems and library versions are unverified.

Validated under qemu-aarch64 with Ubuntu 20.04 cross sysroot: CLI/daemon version, isolated regtest daemon startup, getblockchaininfo and getwalletinfo, graceful shutdown. No native ARM hardware, public chain sync, production wallet or real transaction validation. Use backed-up wallet data and test funds.
