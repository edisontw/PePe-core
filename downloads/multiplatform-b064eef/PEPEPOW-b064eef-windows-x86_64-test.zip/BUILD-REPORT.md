# PEPEPOW Windows x86_64 test package

Integration source: b064eef45f4fbc47dbe338e5840cf17b6a4ed428 (PR #4–#10 with PR #9 Coin Selection refresh); baseline upstream 38e801428688dfd0aee272b4a91819ac1a13ab4e. Existing MinGW GCC 13 win32, static Qt 5.5, Boost 1.63, OpenSSL 1.0.1u and Berkeley DB 4.8 build outputs reused. Qt, wallet and QR enabled; UPnP disabled. Three executables stripped and PE architecture and Windows system-only DLL imports checked. Qt binary is byte-for-byte the prior package that the user reported testing OK; CLI and daemon are reused from preceding build, their source-affecting code unchanged by the subsequent Qt-only refresh.

No new Windows runtime tests or transaction tests were performed for this package; user previously reported testing the Qt build OK. Test with backups and appropriate funds. SHA256SUMS.txt lists files.
