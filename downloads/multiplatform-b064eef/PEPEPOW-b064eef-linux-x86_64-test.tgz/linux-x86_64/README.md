# PEPEPOW Linux x86_64 integration test

Source commit b064eef45f4fbc47dbe338e5840cf17b6a4ed428, includes PR #4–#10. Built on Ubuntu 20.04 x86_64 with GCC 9, Qt 5.12, Boost 1.71, OpenSSL 1.1, libevent 2.1, Berkeley DB 4.8, and OpenLibm 0.8.7. GUI/wallet/QR enabled; UPnP and ZMQ disabled. The binaries are dynamically linked; this is not the same static Qt configuration as the upstream release.

For a compatible Ubuntu 20.04 x86_64 system install: libboost-filesystem1.71.0 libboost-program-options1.71.0 libboost-thread1.71.0 libboost-chrono1.71.0 libssl1.1 libevent-2.1-7 libevent-pthreads-2.1-7 libqt5network5 libqt5widgets5 libqt5gui5 libqt5dbus5 libqt5core5a libqrencode4 libprotobuf17. Qt GUI also requires a working graphical session and Qt's xcb platform dependencies. Other distributions or versions may use incompatible package and library versions and were not validated.

The custom libopenlibm.so.4 is included in lib/. Run ./run-qt.sh, ./run-daemon.sh, or ./run-cli.sh with the desired arguments; these launchers add the package lib directory to LD_LIBRARY_PATH. The binaries are also available by their PEPEPOW names. Wallet database compatibility was built with BDB 4.8. SHA256SUMS.txt records hashes.

Validated: ELF x86-64, no unresolved dynamic libraries in the build container, Qt offscreen -version, CLI and daemon -version, isolated regtest daemon startup, getblockchaininfo and getwalletinfo, and graceful shutdown. No graphical interaction, production chain sync, or real wallet transaction tests were performed. Test with backed-up wallet data and test funds. User reported prior Windows Qt test OK; Linux runtime behavior is not implied by that result.
