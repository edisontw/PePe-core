# PEPEPOW Linux ARM64 desktop test package

Unofficial RC test build. Run `./PEPEPOW_qt` from this extracted directory on an ARM64 Linux desktop; keep `qt.conf`, `lib/` and `plugins/` beside it. The daemon, CLI and transaction tool are individual native executables. Verify with `sha256sum -c SHA256SUMS.txt`. Standard glibc, libstdc++, graphics and desktop services remain host requirements. Use test funds and backups.

This candidate was cross-compiled on x86_64. QEMU checks do not replace native
ARM64 Ubuntu 22.04/24.04 compatibility tests.
