# PEPEPOW v2.9.0.6 Optional Windows candidate

TEST ONLY: built from source commit 0d7d60df283a5685bbf033c92b3fc0d94aff9aac.
Four Windows x86_64 executables are included. Verify the archive SHA256 before
extracting and the individual files with SHA256SUMS.txt. This cross-compiled
candidate passed PE architecture and DLL import inspection. It has not been
executed or wallet-tested on Windows. Use test funds and backed-up data.
